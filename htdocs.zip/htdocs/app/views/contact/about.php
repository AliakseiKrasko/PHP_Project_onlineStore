<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Про нас</title>
    <meta name="description" content="Про нас" />

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" crossorigin="anonymous">
    <link rel="stylesheet" href="/public/css/main.css" type="text/css" charset="utf-8">
</head>
<body>
    <?php require_once 'public/blocks/header.php'; ?>

    <div class="container main">
        <h1>Про нас</h1>
        <p>Здесь просто информация про нас.</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad assumenda blanditiis culpa, cumque impedit,
            itaque laborum natus nemo nihil pariatur placeat porro praesentium, quam repellendus sit totam veniam.
            Veritatis, voluptate.</p>
    </div>

    <?php require_once 'public/blocks/footer.php'; ?>
</body>
</html>