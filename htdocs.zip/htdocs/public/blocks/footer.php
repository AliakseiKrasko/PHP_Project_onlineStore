<footer class="container">
    <div>Все права защищены &copy;</div>
    <div class="social">
        <i class="fab fa-twitter"></i>
        <i class="fab fa-youtube"></i>
        <i class="fab fa-vk"></i>
        <i class="fab fa-telegram"></i>
    </div>
</footer>